// Question 1//

import java.util.*;
import java.util.Scanner;

import static java.util.Arrays.fill;

public class MattressSales {
    public static void main(String[] args) {

        //Declaration of variables//



        //Cozy night mattress sales//
        System.out.println("Enter the number of sales for month 1 for Cozy Nights Monarch mattress: ");
        System.out.println("Enter the number of sales for month 2 for Cozy Nights Monarch mattress: ");
        System.out.println("Enter the number of sales for month 3 for Cozy Nights Monarch mattress: ");

        // Restonic mattress sales//
        System.out.println();
        System.out.println("Enter the number of sales for month 1 for Restonic Barbados mattress: ");
        System.out.println("Enter the number of sales for month 2 for Restonic Barbados mattress: ");
        System.out.println("Enter the number of sales for month 3 for Restonic mattress: ");

        //Sealy mattress saless//
        System.out.println();
        System.out.println("Enter the number of sales for month 1 for Sealy Phuket mattress: ");
        System.out.println("Enter the number of sales for month 2 for Sealy Phuket mattress: ");
        System.out.println("Enter the number of sales for month 3 for Sealy Phuket mattress: ");
        System.out.println();

        Scanner input = new Scanner(System.in);

        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println();
        System.out.println("********************************************");

        // Question 1.2//
        class Product{
            public interface IProduct{
                default int GetTotalProductsSold() {
                    return 0;
                }

                default double GetAverageProductsSold() {
                    return 0;
                }

                default String GetMostPopularProduct() {
                    return null;
                }
            }



        }


        //Question 1.3//
        class PrintProduct{


        }






    }
}

