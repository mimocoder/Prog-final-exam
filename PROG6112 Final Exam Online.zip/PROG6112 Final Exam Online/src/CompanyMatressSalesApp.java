// Question 2//

import javax.swing.*;

public class CompanyMatressSalesApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // The declaration of the arrays//
        final int NUMBER_OF_ITEMS = 1;
        String[] CustomerName = {"Joe Bloggs"};
        double[] price = {3500};
        double[] VAT = {525.0};
        double[] Commisson = {175.0};
        double[] Total = {4200.0};

        String strItem;
        double itemPrice = 0.0;
        double itemVAT = 0.0;
        double itemCommisson = 0.0;
        double itemTotal = 0.0;

        // Validates the item price//
        boolean isValidItemPrice = false;
        strItem = JOptionPane.showInputDialog(null, " Enter Price: ");
        itemPrice = Double.parseDouble(strItem);

        //Validates the customer name//
        boolean isValidCustomerName = false;
        strItem = JOptionPane.showInputDialog(null, " Customer Name: ");
        CustomerName = strItem.split("Joe Bloggs");

        for (double i : price) {
            if (CustomerName[0].equals(CustomerName[1])) {
                itemPrice = i;
                isValidCustomerName = true;
            }
        }
        if (!isValidCustomerName) {
            JOptionPane.showMessageDialog(null, "Customer Name is invalid");

        }

        //Question 2.5//

    }

    private interface IProductCalculations {
        default double GetVat() {
            return 0;
        }

        default double GetCommisson() {
            return 0;
        }

        double GetTotal();
        default double GetAverageProductsSold() {
            return 0;
        }
    }
}

